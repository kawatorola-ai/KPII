/**
 * 2026 年度 KPI 查詢系統 - 預設假資料 (Mock Data)
 * 包含公司願景共同目標 (2.5 億元營收) 與跨部門員工個人 OKR/KPI
 */

export const initialCompanyVision = {
  year: 2026,
  goalRevenue: 250000000, // 2.5 億元年度營收
  currentRevenue: 182500000, // 目前累積達成營收 (約 73%)
  currency: 'NTD',
  title: '2026 年度公司共同營運目標',
  subTitle: '攜手邁向 2.5 億元年度營收里程碑，驅動全方位產品與服務升級',
  quarters: [
    { name: 'Q1 (已達成)', target: 50000000, actual: 52000000, status: 'achieved' },
    { name: 'Q2 (已達成)', target: 60000000, actual: 63500000, status: 'achieved' },
    { name: 'Q3 (進行中)', target: 70000000, actual: 67000000, status: 'in_progress' },
    { name: 'Q4 (預測)', target: 70000000, actual: 0, status: 'pending' },
  ],
  lastUpdated: '2026-09-07'
};

export const initialEmployees = [
  {
    id: 'EMP-2026-01',
    nationalId: 'A123456789',
    name: '王大明',
    department: '業務部',
    title: '大中華區資深業務經理',
    email: 'daming.wang@company.com',
    overallAchievement: 112, // 超額達成
    statusBadge: '超額卓越',
    statusColor: 'emerald',
    metrics: [
      {
        id: 'M-01',
        category: '業績營收',
        title: '企業級客戶年度簽約營收',
        targetNum: 5000,
        currentNum: 5800,
        unit: '萬元',
        weight: 40,
        achievement: 116,
        status: 'exceeded',
        description: '負責金融與半導體產業大型 Enterprise 客戶拓展，年約續約率 > 95%'
      },
      {
        id: 'M-02',
        category: '新客開拓',
        title: '高價值新簽約客戶數',
        targetNum: 20,
        currentNum: 23,
        unit: '家',
        weight: 25,
        achievement: 115,
        status: 'exceeded',
        description: '單筆合約金額高於 150 萬元以上之策略型新客戶'
      },
      {
        id: 'M-03',
        category: '客戶體驗',
        title: '業務服務淨推薦值 (NPS)',
        targetNum: 85,
        currentNum: 88,
        unit: '分',
        weight: 20,
        achievement: 103,
        status: 'on_track',
        description: '季度客戶滿意度回饋問卷調查綜合評分'
      },
      {
        id: 'M-04',
        category: '團隊賦能',
        title: '初階業務同仁培訓與認證',
        targetNum: 4,
        currentNum: 4,
        unit: '人',
        weight: 15,
        achievement: 100,
        status: 'on_track',
        description: '擔任內部業師，協助新進業務於 3 個月內獨立簽下首張訂單'
      }
    ]
  },
  {
    id: 'EMP-2026-02',
    nationalId: 'B234567890',
    name: '林小涵',
    department: '研發部',
    title: '核心架構資深前端工程師',
    email: 'xiaohan.lin@company.com',
    overallAchievement: 88, // 良好穩定
    statusBadge: '穩定推進',
    statusColor: 'indigo',
    metrics: [
      {
        id: 'M-05',
        category: '架構重構',
        title: '新一代微前端 Design System 覆蓋率',
        targetNum: 90,
        currentNum: 82,
        unit: '%',
        weight: 35,
        achievement: 91,
        status: 'on_track',
        description: '完成前台與後台管理模組元件化，降低代碼重複率 40%'
      },
      {
        id: 'M-06',
        category: '效能指標',
        title: 'Web Core Vitals (LCP) 首屏載入優化',
        targetNum: 1.5,
        currentNum: 1.65,
        unit: '秒',
        weight: 25,
        achievement: 90,
        status: 'on_track',
        description: '全站 P90 首屏渲染時間壓降至 1.5 秒以內'
      },
      {
        id: 'M-07',
        category: '工程質量',
        title: '前端單元測試與 E2E 覆蓋率',
        targetNum: 80,
        currentNum: 68,
        unit: '%',
        weight: 25,
        achievement: 85,
        status: 'in_progress',
        description: '核心交易流與認證授權模組自動化回歸測試覆蓋'
      },
      {
        id: 'M-08',
        category: '敏捷產出',
        title: 'Sprint 準時交付率 (On-Time Delivery)',
        targetNum: 95,
        currentNum: 85,
        unit: '%',
        weight: 15,
        achievement: 89,
        status: 'in_progress',
        description: '跨部門協作需求無延宕交付比率'
      }
    ]
  },
  {
    id: 'EMP-2026-03',
    nationalId: 'C345678901',
    name: '張雅婷',
    department: '行銷部',
    title: '數位增長資深專員',
    email: 'yating.zhang@company.com',
    overallAchievement: 65, // 需衝刺注意
    statusBadge: '需加速衝刺',
    statusColor: 'amber',
    metrics: [
      {
        id: 'M-09',
        category: '增長獲客',
        title: '年度 MQL (行銷合格潛在名單) 產出量',
        targetNum: 1200,
        currentNum: 740,
        unit: '筆',
        weight: 40,
        achievement: 61,
        status: 'warning',
        description: '藉由白皮書下載、線上研討會與精準搜尋廣告獲取有效名單'
      },
      {
        id: 'M-10',
        category: '成本控制',
        title: 'CAC (單客獲取成本) 壓降比率',
        targetNum: 25,
        currentNum: 15,
        unit: '%',
        weight: 25,
        achievement: 60,
        status: 'warning',
        description: '透過 SEO 內容行銷與社群裂變降低對付費廣告依賴'
      },
      {
        id: 'M-11',
        category: '品牌聲量',
        title: '產業年度高峰論壇參與人次',
        targetNum: 600,
        currentNum: 480,
        unit: '人',
        weight: 20,
        achievement: 80,
        status: 'in_progress',
        description: '2026 Q4 將舉辦線上線下混合旗艦年度高峰發表會'
      },
      {
        id: 'M-12',
        category: '會員經營',
        title: '官方技術電子報訂閱增長率',
        targetNum: 50,
        currentNum: 38,
        unit: '%',
        weight: 15,
        achievement: 76,
        status: 'in_progress',
        description: '雙週出刊高質量原創產業技術動態'
      }
    ]
  },
  {
    id: 'EMP-2026-04',
    nationalId: 'D456789012',
    name: '陳冠宇',
    department: '人力資源部',
    title: '人才招募與發展主管',
    email: 'guanyu.chen@company.com',
    overallAchievement: 96,
    statusBadge: '績效卓越',
    statusColor: 'emerald',
    metrics: [
      {
        id: 'M-13',
        category: '組織招聘',
        title: '關鍵技術與業務主管職位到位率',
        targetNum: 100,
        currentNum: 95,
        unit: '%',
        weight: 40,
        achievement: 95,
        status: 'on_track',
        description: '支援公司 2.5 億營收擴張，完成 35 位核心專業人才到職'
      },
      {
        id: 'M-14',
        category: '人才留任',
        title: '新進同仁第一年留任率',
        targetNum: 90,
        currentNum: 92,
        unit: '%',
        weight: 30,
        achievement: 102,
        status: 'exceeded',
        description: '建立完整的 Buddy 導師與 30/60/90 天關懷跟進機制'
      },
      {
        id: 'M-15',
        category: '學習發展',
        title: '員工培訓總滿意度評分',
        targetNum: 90,
        currentNum: 91,
        unit: '分',
        weight: 20,
        achievement: 101,
        status: 'on_track',
        description: '領導力學院與各職能技能工作坊學員課後滿意度'
      },
      {
        id: 'M-16',
        category: '制度創新',
        title: '績效管理 OKR 數位化與流程簡化',
        targetNum: 100,
        currentNum: 90,
        unit: '%',
        weight: 10,
        achievement: 90,
        status: 'on_track',
        description: '推動全員季度 Check-in 平台化與即時反饋回饋系統'
      }
    ]
  },
  {
    id: 'EMP-2026-05',
    nationalId: 'E567890123',
    name: '黃品妤',
    department: '產品設計部',
    title: '使用者經驗首席設計師',
    email: 'pinyu.huang@company.com',
    overallAchievement: 94,
    statusBadge: '績效卓越',
    statusColor: 'emerald',
    metrics: [
      {
        id: 'M-17',
        category: '體驗評測',
        title: '客戶端旗艦系統可用性 SUS 評分',
        targetNum: 85,
        currentNum: 86,
        unit: '分',
        weight: 35,
        achievement: 101,
        status: 'exceeded',
        description: '針對企業用戶執行 20 場深度易用性訪談並完成核心流程改良'
      },
      {
        id: 'M-18',
        category: '設計資產',
        title: '跨平台 UI Kit 與無障礙 WCAG 2.1 AA 規範標準化',
        targetNum: 100,
        currentNum: 92,
        unit: '%',
        weight: 35,
        achievement: 92,
        status: 'on_track',
        description: '建立 Figma 官方設計系統，同步至前端 React 代碼庫'
      },
      {
        id: 'M-19',
        category: '原型驗證',
        title: 'AI 智慧助理核心功能概念原型轉化率',
        targetNum: 80,
        currentNum: 75,
        unit: '%',
        weight: 30,
        achievement: 93,
        status: 'on_track',
        description: '通過內部評審並順利移交研發團隊開發上線之原型比例'
      }
    ]
  }
];
