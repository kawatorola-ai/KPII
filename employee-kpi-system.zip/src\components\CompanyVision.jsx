import React from 'react';
import { useKPI } from '../context/KPIContext';
import { TrendingUp, Target, Award, Calendar, ArrowUpRight } from 'lucide-react';

export const CompanyVision = () => {
  const { companyVision } = useKPI();

  const goal = companyVision.goalRevenue || 250000000;
  const current = companyVision.currentRevenue || 0;
  const progressPercent = Math.min(Math.round((current / goal) * 1000) / 10, 100);
  const remaining = Math.max(goal - current, 0);

  // 格式化億元與千分位
  const formatYuan = (val) => {
    const yi = val / 100000000;
    if (yi >= 1) {
      return `${yi.toFixed(2)} 億元`;
    }
    return `${(val / 10000).toLocaleString()} 萬元`;
  };

  const formatNTD = (val) => `NT$ ${val.toLocaleString()}`;

  return (
    <section className="bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-900 rounded-2xl text-white p-6 md:p-8 shadow-xl relative overflow-hidden border border-indigo-500/20">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 -mb-16 w-60 h-60 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Top Tag & Header */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 mb-2">
            <Target className="w-3.5 h-3.5 text-indigo-300" />
            <span>2026 全體同仁共同願景與策略目標</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white flex items-center gap-3">
            年度營收共同目標：<span className="text-emerald-400">{formatYuan(goal)}</span>
          </h1>
          <p className="text-slate-300 text-sm mt-1 max-w-2xl">
            凝聚全員 OKR/KPI 動能，邁向 {formatYuan(goal)} 里程碑。每一位同仁的卓越付出，都是實現公司願景不可或缺的關鍵基石。
          </p>
        </div>

        {/* Quick Stats Pill */}
        <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md px-5 py-3 rounded-xl border border-white/15 self-start md:self-auto">
          <div className="text-right">
            <div className="text-xs text-slate-300 uppercase tracking-wider">整體達成率</div>
            <div className="text-3xl font-black text-emerald-400 tracking-tight flex items-center justify-end gap-1">
              {progressPercent}%
              <ArrowUpRight className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar Section */}
      <div className="relative z-10 pt-6">
        <div className="flex justify-between items-end mb-2 text-xs md:text-sm">
          <div>
            <span className="text-slate-400">目前累積營收：</span>
            <span className="font-bold text-white text-base md:text-lg ml-1 text-emerald-300">
              {formatNTD(current)}
            </span>
            <span className="text-xs text-emerald-400/90 ml-1.5">
              ({formatYuan(current)})
            </span>
          </div>
          <div className="text-right">
            <span className="text-slate-400">距離目標差距：</span>
            <span className="font-semibold text-amber-300 ml-1">
              {remaining === 0 ? '已全面達標 🎉' : formatNTD(remaining)}
            </span>
          </div>
        </div>

        {/* Progress Track */}
        <div className="w-full bg-slate-800/80 rounded-full h-5 md:h-6 p-1 border border-white/15 relative shadow-inner overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 transition-all duration-1000 relative"
            style={{ width: `${Math.max(progressPercent, 2)}%` }}
          >
            {/* Shimmer overlay animation */}
            <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
            <div className="absolute right-1 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow" />
          </div>
        </div>

        {/* Milestones / Quarters */}
        <div className="grid grid-cols-4 mt-3 pt-2 text-[11px] md:text-xs text-slate-400 border-t border-white/5">
          <div className="text-left">
            <span className="block font-medium text-slate-300">Q1 結算</span>
            <span className="text-emerald-400 font-semibold">104% (超標)</span>
          </div>
          <div className="text-center">
            <span className="block font-medium text-slate-300">Q2 結算</span>
            <span className="text-emerald-400 font-semibold">105% (超標)</span>
          </div>
          <div className="text-center">
            <span className="block font-medium text-slate-300">Q3 衝刺</span>
            <span className="text-indigo-300 font-semibold">95% (進行中)</span>
          </div>
          <div className="text-right">
            <span className="block font-medium text-slate-300">Q4 展望</span>
            <span className="text-slate-400 font-medium">{formatYuan(goal)} 全面衝刺</span>
          </div>
        </div>
      </div>
    </section>
  );
};
