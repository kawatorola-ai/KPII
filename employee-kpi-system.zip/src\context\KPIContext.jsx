import React, { createContext, useContext, useState } from 'react';
import { initialCompanyVision, initialEmployees } from '../data/mockData';

const KPIContext = createContext();

export const KPIProvider = ({ children }) => {
  const [companyVision, setCompanyVision] = useState(initialCompanyVision);
  const [employees, setEmployees] = useState(initialEmployees);
  const [currentEmployee, setCurrentEmployee] = useState(initialEmployees[0]); // 預設第一位員工以利預覽
  const [isLoggedIn, setIsLoggedIn] = useState(true); // 預設已登入方便即時查看
  const [lastImportInfo, setLastImportInfo] = useState(null);
  const [consultationHistory, setConsultationHistory] = useState([]);

  // 身分證登入
  const login = (nationalId) => {
    const cleanId = nationalId.trim().toUpperCase();
    const found = employees.find(emp => emp.nationalId.toUpperCase() === cleanId);
    if (found) {
      setCurrentEmployee(found);
      setIsLoggedIn(true);
      return { success: true, employee: found };
    }
    return { success: false, message: '查無此身分證字號之員工紀錄，請確認後重試或聯繫 HR！' };
  };

  // 登出
  const logout = () => {
    setIsLoggedIn(false);
    setCurrentEmployee(null);
  };

  // 切換指定員工 (方便管理者與預覽測試)
  const switchEmployee = (empId) => {
    const found = employees.find(emp => emp.id === empId || emp.nationalId === empId);
    if (found) {
      setCurrentEmployee(found);
      setIsLoggedIn(true);
    }
  };

  // 從 Excel 解析後的資料覆蓋狀態
  const importDataFromExcel = ({ updatedCompanyVision, updatedEmployees, fileName }) => {
    if (updatedCompanyVision) {
      setCompanyVision(prev => ({
        ...prev,
        ...updatedCompanyVision,
        lastUpdated: new Date().toISOString().split('T')[0]
      }));
    }

    if (updatedEmployees && updatedEmployees.length > 0) {
      setEmployees(updatedEmployees);
      // 若當前登入員工有更新，同步更新當前視圖
      if (currentEmployee) {
        const updatedCurrent = updatedEmployees.find(
          e => e.nationalId === currentEmployee.nationalId || e.id === currentEmployee.id
        );
        if (updatedCurrent) {
          setCurrentEmployee(updatedCurrent);
        } else {
          setCurrentEmployee(updatedEmployees[0]);
        }
      }
    }

    setLastImportInfo({
      fileName,
      time: new Date().toLocaleTimeString(),
      employeeCount: updatedEmployees ? updatedEmployees.length : employees.length,
      revenueUpdated: !!updatedCompanyVision
    });
  };

  // 預約 HR 諮詢會議
  const scheduleConsultation = (details) => {
    const newBooking = {
      id: 'REQ-' + Date.now().toString().slice(-6),
      employeeId: currentEmployee?.id,
      employeeName: currentEmployee?.name,
      department: currentEmployee?.department,
      nationalId: currentEmployee?.nationalId,
      topic: details.topic,
      notes: details.notes || '無補充備註',
      preferredTime: details.preferredTime || '最近可用工作日 (由 HR 排定)',
      status: '已排入行事曆',
      createdAt: new Date().toLocaleString()
    };
    setConsultationHistory(prev => [newBooking, ...prev]);
    return newBooking;
  };

  return (
    <KPIContext.Provider
      value={{
        companyVision,
        employees,
        currentEmployee,
        isLoggedIn,
        lastImportInfo,
        consultationHistory,
        login,
        logout,
        switchEmployee,
        importDataFromExcel,
        scheduleConsultation
      }}
    >
      {children}
    </KPIContext.Provider>
  );
};

export const useKPI = () => {
  const context = useContext(KPIContext);
  if (!context) {
    throw new Error('useKPI must be used within a KPIProvider');
  }
  return context;
};
