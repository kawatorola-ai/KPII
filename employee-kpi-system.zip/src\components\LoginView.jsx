import React, { useState } from 'react';
import { useKPI } from '../context/KPIContext';
import { ShieldCheck, UserCheck, AlertCircle, Sparkles, Building2 } from 'lucide-react';

export const LoginView = () => {
  const { login, employees } = useKPI();
  const [nationalId, setNationalId] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!nationalId.trim()) {
      setError('請輸入身分證字號');
      return;
    }
    const result = login(nationalId);
    if (!result.success) {
      setError(result.message);
    } else {
      setError('');
    }
  };

  const handleQuickLogin = (id) => {
    setNationalId(id);
    const result = login(id);
    if (!result.success) {
      setError(result.message);
    } else {
      setError('');
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
        {/* Header decoration */}
        <div className="bg-gradient-to-r from-blue-700 via-indigo-600 to-indigo-800 p-8 text-white text-center relative">
          <div className="inline-flex p-3 bg-white/10 rounded-2xl backdrop-blur-md mb-3 ring-1 ring-white/20">
            <Building2 className="w-8 h-8 text-blue-100" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight">2026 年度 KPI 員工查詢系統</h2>
          <p className="text-blue-100/90 text-sm mt-1">
            輸入您的身分證字號，查看個人 OKR/KPI 目標與公司願景
          </p>
          <div className="absolute top-3 right-3 text-xs bg-white/15 px-2.5 py-1 rounded-full text-blue-100">
            🔒 企業內部專屬
          </div>
        </div>

        {/* Login Form */}
        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="nationalId" className="block text-sm font-medium text-slate-700 mb-1.5">
                身分證字號 (National ID)
              </label>
              <div className="relative rounded-lg shadow-sm">
                <input
                  type="text"
                  id="nationalId"
                  value={nationalId}
                  onChange={(e) => {
                    setNationalId(e.target.value.toUpperCase());
                    setError('');
                  }}
                  placeholder="例如：A123456789"
                  maxLength={10}
                  className="block w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-900 tracking-wider font-mono text-base uppercase transition-all duration-150"
                  autoComplete="off"
                />
              </div>
              <p className="mt-1 text-xs text-slate-500">
                英文字母大寫，共 10 碼（僅供內部績效校驗）
              </p>
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-white font-semibold bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 transition-colors shadow-md shadow-indigo-600/20"
            >
              <ShieldCheck className="w-5 h-5" />
              登入查看 2026 年度 KPI
            </button>
          </form>

          {/* Quick Mock Login for Demo / Testing */}
          <div className="mt-8 pt-6 border-t border-slate-100">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>快速測試登入（點擊直接切換不同部門同仁）：</span>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {employees.slice(0, 5).map((emp) => (
                <button
                  key={emp.id}
                  onClick={() => handleQuickLogin(emp.nationalId)}
                  className="flex items-center justify-between px-3 py-2 text-xs bg-slate-50 hover:bg-indigo-50/70 hover:border-indigo-200 border border-slate-200 rounded-lg text-slate-700 transition group"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900 group-hover:text-indigo-600">
                      {emp.name}
                    </span>
                    <span className="text-slate-400">|</span>
                    <span className="text-slate-600">{emp.department}</span>
                    <span className="text-slate-400">({emp.title})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-600">
                      {emp.nationalId}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      emp.overallAchievement >= 100 ? 'bg-emerald-100 text-emerald-700' :
                      emp.overallAchievement >= 80 ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {emp.overallAchievement}%
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
