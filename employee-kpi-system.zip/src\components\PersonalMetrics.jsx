import React, { useState } from 'react';
import { useKPI } from '../context/KPIContext';
import { BarChart3, PieChart as PieIcon, CheckCircle2, Clock, AlertTriangle, TrendingUp, HelpCircle } from 'lucide-react';

export const PersonalMetrics = () => {
  const { currentEmployee } = useKPI();
  const [chartView, setChartView] = useState('both'); // 'both' | 'bars' | 'pie'

  if (!currentEmployee || !currentEmployee.metrics) {
    return (
      <div className="bg-white rounded-2xl p-8 text-center text-slate-500 border border-slate-200">
        目前無該員工之 OKR/KPI 指標數據。
      </div>
    );
  }

  const { metrics, overallAchievement, name, department } = currentEmployee;

  // 統計摘要
  const totalWeight = metrics.reduce((acc, m) => acc + (m.weight || 0), 0);
  const exceededCount = metrics.filter(m => m.achievement >= 100).length;
  const inProgressCount = metrics.filter(m => m.achievement >= 75 && m.achievement < 100).length;
  const warningCount = metrics.filter(m => m.achievement < 75).length;

  // 計算圓餅圖 SVG 圓弧角度與顏色
  const colors = [
    '#6366f1', // indigo
    '#0ea5e9', // sky
    '#10b981', // emerald
    '#f59e0b', // amber
    '#8b5cf6', // purple
    '#ec4899', // pink
  ];

  // 圓餅圖計算
  let cumulativeAngle = 0;
  const pieSlices = metrics.map((metric, idx) => {
    const fraction = (metric.weight || 25) / totalWeight;
    const angle = fraction * 360;
    const startAngle = cumulativeAngle;
    cumulativeAngle += angle;
    return {
      ...metric,
      fraction,
      startAngle,
      endAngle: cumulativeAngle,
      color: colors[idx % colors.length]
    };
  });

  // SVG 圓環路徑工具
  const polarToCartesian = (centerX, centerY, radius, angleInDegrees) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians),
    };
  };

  const describeArc = (x, y, radius, startAngle, endAngle) => {
    const start = polarToCartesian(x, y, radius, endAngle);
    const end = polarToCartesian(x, y, radius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    return [
      'M', start.x, start.y,
      'A', radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(' ');
  };

  return (
    <div className="space-y-6">
      {/* 總覽指標小卡 Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm">
          <div className="text-xs text-slate-500 font-medium">年度綜合考評</div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className={`text-2xl md:text-3xl font-extrabold ${
              overallAchievement >= 100 ? 'text-emerald-600' :
              overallAchievement >= 80 ? 'text-indigo-600' : 'text-amber-600'
            }`}>
              {overallAchievement}%
            </span>
            <span className="text-xs text-slate-400">達成</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">依指標權重綜合計分</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm">
          <div className="text-xs text-slate-500 font-medium flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            已達標 / 超額項目
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl md:text-3xl font-extrabold text-slate-800">{exceededCount}</span>
            <span className="text-xs text-slate-400">/ {metrics.length} 項</span>
          </div>
          <div className="text-[11px] text-emerald-600 mt-1 font-medium">進展優異超越預期</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm">
          <div className="text-xs text-slate-500 font-medium flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            正常推進中項目
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl md:text-3xl font-extrabold text-slate-800">{inProgressCount}</span>
            <span className="text-xs text-slate-400">/ {metrics.length} 項</span>
          </div>
          <div className="text-[11px] text-indigo-600 mt-1 font-medium">符合年度預期進度</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-sm">
          <div className="text-xs text-slate-500 font-medium flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            需關注 / 衝刺項目
          </div>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl md:text-3xl font-extrabold text-slate-800">{warningCount}</span>
            <span className="text-xs text-slate-400">/ {metrics.length} 項</span>
          </div>
          <div className="text-[11px] text-amber-600 mt-1 font-medium">建議與主管對齊資源</div>
        </div>
      </div>

      {/* 視覺化圖表主區塊 */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 mb-6 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              個人 2026 年度 OKR / KPI 達成率視覺化
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              即時追蹤各項關鍵結果衡量標準（KR）達成進展與權重分配
            </p>
          </div>

          {/* 切換圖表模式按鈕 */}
          <div className="inline-flex bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              onClick={() => setChartView('both')}
              className={`px-3 py-1.5 rounded-lg transition ${chartView === 'both' ? 'bg-white text-indigo-600 shadow-sm' : 'hover:text-slate-900'}`}
            >
              長條 + 圓餅全覽
            </button>
            <button
              onClick={() => setChartView('bars')}
              className={`px-3 py-1.5 rounded-lg transition ${chartView === 'bars' ? 'bg-white text-indigo-600 shadow-sm' : 'hover:text-slate-900'}`}
            >
              長條達成圖
            </button>
            <button
              onClick={() => setChartView('pie')}
              className={`px-3 py-1.5 rounded-lg transition ${chartView === 'pie' ? 'bg-white text-indigo-600 shadow-sm' : 'hover:text-slate-900'}`}
            >
              權重圓餅圖
            </button>
          </div>
        </div>

        {/* 圖表展示容器 */}
        <div className={`grid gap-8 ${chartView === 'both' ? 'lg:grid-cols-12' : 'grid-cols-1'}`}>
          {/* 1. 長條圖視覺化 Bar Chart */}
          {(chartView === 'both' || chartView === 'bars') && (
            <div className={chartView === 'both' ? 'lg:col-span-7' : 'w-full'}>
              <h4 className="text-sm font-semibold text-slate-700 mb-4 flex items-center gap-1.5">
                <span>各項 OKR 達成率長條對比</span>
                <span className="text-xs font-normal text-slate-400">（基準線 100%）</span>
              </h4>

              <div className="space-y-4">
                {metrics.map((metric, idx) => {
                  const percent = metric.achievement || 0;
                  const barColor =
                    percent >= 100 ? 'bg-emerald-500' :
                    percent >= 80 ? 'bg-indigo-600' : 'bg-amber-500';

                  return (
                    <div key={metric.id || idx} className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                            style={{ backgroundColor: colors[idx % colors.length] }}
                          />
                          <span className="font-semibold text-slate-800 truncate max-w-[220px] sm:max-w-xs">
                            {metric.title}
                          </span>
                          <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                            權重 {metric.weight}%
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-500">
                            {metric.currentNum} / {metric.targetNum} {metric.unit}
                          </span>
                          <span className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                            percent >= 100 ? 'bg-emerald-100 text-emerald-800' :
                            percent >= 80 ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {percent}%
                          </span>
                        </div>
                      </div>

                      {/* Bar Track with 100% target marker */}
                      <div className="relative w-full bg-slate-100 rounded-full h-3.5 overflow-hidden">
                        {/* 100% Target vertical dash */}
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-slate-400 z-10 opacity-70"
                          style={{ left: '80%' }}
                          title="100% 達成標準線"
                        />
                        {/* Actual progress bar (scaled such that 100% is at 80% mark, up to 125% max) */}
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${barColor}`}
                          style={{
                            width: `${Math.min((percent / 125) * 100, 100)}%`
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-end gap-4 mt-4 text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> ≥100% 超額達成
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" /> 80%~99% 達標推進
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> &lt;80% 需加強衝刺
                </span>
              </div>
            </div>
          )}

          {/* 2. 甜甜圈 / 圓餅圖 Donut Chart */}
          {(chartView === 'both' || chartView === 'pie') && (
            <div className={`flex flex-col items-center justify-center p-4 bg-slate-50/70 rounded-xl border border-slate-100 ${chartView === 'both' ? 'lg:col-span-5' : 'w-full'}`}>
              <h4 className="text-sm font-semibold text-slate-700 mb-3 text-center">
                指標權重與達成率圓餅圖
              </h4>

              <div className="relative w-48 h-48 my-2">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  {pieSlices.map((slice, idx) => {
                    const strokeWidth = 16;
                    const radius = 38;
                    const path = describeArc(50, 50, radius, slice.startAngle, slice.endAngle - 0.5);
                    return (
                      <path
                        key={idx}
                        d={path}
                        fill="none"
                        stroke={slice.color}
                        strokeWidth={strokeWidth}
                        className="transition-all duration-500 hover:opacity-80 cursor-pointer"
                      >
                        <title>{`${slice.title}: 權重 ${slice.weight}% (達成率 ${slice.achievement}%)`}</title>
                      </path>
                    );
                  })}
                </svg>

                {/* Center text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-[11px] text-slate-400 font-medium">總達成率</span>
                  <span className="text-2xl font-black text-slate-800">
                    {overallAchievement}%
                  </span>
                  <span className="text-[10px] text-indigo-600 font-semibold">{department}</span>
                </div>
              </div>

              {/* Legend */}
              <div className="w-full mt-3 grid grid-cols-1 gap-1.5 text-xs">
                {pieSlices.map((slice, idx) => (
                  <div key={idx} className="flex items-center justify-between text-[11px] text-slate-600">
                    <div className="flex items-center gap-1.5 truncate max-w-[180px]">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: slice.color }} />
                      <span className="truncate">{slice.title}</span>
                    </div>
                    <span className="font-semibold text-slate-700 flex-shrink-0">
                      {slice.weight}% 權重
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 詳細 OKR 條目明細列表 Cards List */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80">
        <h4 className="text-base font-bold text-slate-900 mb-4">
          2026 OKR/KPI 目標明細與關鍵衡量成果 (Key Results)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.map((m, idx) => {
            const isExceeded = m.achievement >= 100;
            const isWarning = m.achievement < 75;

            return (
              <div
                key={m.id || idx}
                className="p-4 rounded-xl border border-slate-200 bg-white hover:border-indigo-300 transition-shadow hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">
                      {m.category}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                      isExceeded ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      isWarning ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-indigo-50 text-indigo-700 border border-indigo-200'
                    }`}>
                      {m.achievement}% 達成
                    </span>
                  </div>

                  <h5 className="font-bold text-slate-900 text-sm">{m.title}</h5>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {m.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                  <div>
                    <span className="text-slate-400">目前進度：</span>
                    <strong className="text-slate-800">{m.currentNum}</strong>
                    <span className="text-slate-400 ml-1">/ {m.targetNum} {m.unit}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-400">指標權重：</span>
                    <strong className="text-indigo-600">{m.weight}%</strong>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
