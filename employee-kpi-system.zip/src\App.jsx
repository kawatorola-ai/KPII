import React, { useState } from 'react';
import { KPIProvider, useKPI } from './context/KPIContext';
import { LoginView } from './components/LoginView';
import { CompanyVision } from './components/CompanyVision';
import { EmployeeHeader } from './components/EmployeeHeader';
import { PersonalMetrics } from './components/PersonalMetrics';
import { ConsultationSection } from './components/ConsultationSection';
import { HrExcelImporter } from './components/HrExcelImporter';
import { Building2, FileSpreadsheet, ShieldCheck } from 'lucide-react';

const DashboardContent = () => {
  const { isLoggedIn, currentEmployee } = useKPI();
  const [isHrModalOpen, setIsHrModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col">
      {/* Top Corporate Navigation Bar */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-indigo-500/20">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <span className="text-base font-bold text-slate-900 tracking-tight block leading-tight">
                企業內部員工 KPI 查詢系統
              </span>
              <span className="text-[11px] text-slate-400 font-medium">
                2026 年度 OKR & 績效考核儀表板
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsHrModalOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-semibold border border-emerald-200 transition shadow-xs"
              title="由 HR 上傳 Excel 動態更新營收與各部門員工數據"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">HR 專用 Excel 匯入</span>
              <span className="sm:hidden">Excel 匯入</span>
            </button>

            {isLoggedIn && currentEmployee && (
              <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-slate-200 text-xs text-slate-600">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>已驗證：<strong>{currentEmployee.name}</strong></span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!isLoggedIn ? (
          <LoginView />
        ) : (
          <div className="space-y-8">
            {/* 1. 公司願景區塊 (頂部 2.5 億元年度營收進度條) */}
            <CompanyVision />

            {/* 2. 員工身分與部門標頭 */}
            <EmployeeHeader onOpenHrModal={() => setIsHrModalOpen(true)} />

            {/* 3. 個人指標區塊 (長條圖 / 圓餅圖 / OKR卡片) */}
            <PersonalMetrics />

            {/* 4. 支援與諮詢 (HR 諮詢會議預約提示與按鈕) */}
            <ConsultationSection />
          </div>
        )}
      </main>

      {/* HR Excel 匯入彈出視窗 */}
      <HrExcelImporter
        isOpen={isHrModalOpen}
        onClose={() => setIsHrModalOpen(false)}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200/80 py-6 mt-12 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 公司內部人力資源發展與績效考評委員會 • 機密等級：內部專用</p>
          <p className="mt-1 text-[11px] text-slate-400/80">
            若對指標設定有任何疑義，請善用下方諮詢預約功能或聯絡人力資源部。
          </p>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <KPIProvider>
      <DashboardContent />
    </KPIProvider>
  );
}
