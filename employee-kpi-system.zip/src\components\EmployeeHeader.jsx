import React from 'react';
import { useKPI } from '../context/KPIContext';
import { User, LogOut, FileSpreadsheet, Building, Briefcase, Award, ChevronDown } from 'lucide-react';

export const EmployeeHeader = ({ onOpenHrModal }) => {
  const { currentEmployee, employees, switchEmployee, logout } = useKPI();

  if (!currentEmployee) return null;

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
      {/* Employee Identity Info */}
      <div className="flex items-start sm:items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-blue-500 text-white flex items-center justify-center font-bold text-xl shadow-md shadow-indigo-500/20 flex-shrink-0">
          {currentEmployee.name ? currentEmployee.name.slice(0, 1) : '員'}
        </div>
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
              {currentEmployee.name}
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
              {currentEmployee.department}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
              currentEmployee.overallAchievement >= 100 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
              currentEmployee.overallAchievement >= 80 ? 'bg-blue-50 text-blue-700 border border-blue-200' :
              'bg-amber-50 text-amber-700 border border-amber-200'
            }`}>
              {currentEmployee.statusBadge || '進行中'} ({currentEmployee.overallAchievement}%)
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-y-1 gap-x-4 mt-1.5 text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <Briefcase className="w-3.5 h-3.5 text-slate-400" />
              {currentEmployee.title}
            </span>
            <span>•</span>
            <span className="font-mono">身分證：{currentEmployee.nationalId}</span>
            <span>•</span>
            <span>工號：{currentEmployee.id}</span>
            <span>•</span>
            <span>考核年度：<strong className="text-slate-700">2026 年度</strong></span>
          </div>
        </div>
      </div>

      {/* Action Controls & Fast Switcher */}
      <div className="flex flex-wrap items-center gap-3 pt-4 lg:pt-0 border-t lg:border-t-0 border-slate-100">
        {/* Switch Employee Selector */}
        <div className="relative inline-block text-left">
          <select
            value={currentEmployee.id}
            onChange={(e) => switchEmployee(e.target.value)}
            className="appearance-none bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium py-2 pl-3 pr-8 rounded-xl border border-slate-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-500"
            title="切換員工檢視不同部門"
          >
            {employees.map(emp => (
              <option key={emp.id} value={emp.id}>
                切換：{emp.name} ({emp.department})
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* HR Import Button */}
        <button
          onClick={onOpenHrModal}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition shadow-sm"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          <span>HR 專用 Excel 匯入</span>
        </button>

        {/* Logout Button */}
        <button
          onClick={logout}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition"
        >
          <LogOut className="w-4 h-4" />
          <span>登出</span>
        </button>
      </div>
    </div>
  );
};
