import React, { useState } from 'react';
import { useKPI } from '../context/KPIContext';
import { HelpCircle, Calendar, CheckCircle, MessageSquare, Clock, User, X } from 'lucide-react';

export const ConsultationSection = () => {
  const { currentEmployee, scheduleConsultation, consultationHistory } = useKPI();
  const [isOpen, setIsOpen] = useState(false);
  const [topic, setTopic] = useState('目標設定疑義與指標調整');
  const [preferredTime, setPreferredTime] = useState('下週二 14:00 - 15:00 (可配合主管會議)');
  const [notes, setNotes] = useState('');
  const [submittedBooking, setSubmittedBooking] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = scheduleConsultation({
      topic,
      preferredTime,
      notes
    });
    setSubmittedBooking(result);
    setIsOpen(false);
  };

  return (
    <div className="mt-8">
      {/* 最下方支援與諮詢提示橫幅 */}
      <div className="bg-gradient-to-r from-indigo-50 via-blue-50 to-slate-50 border border-indigo-100/80 rounded-2xl p-6 sm:p-8 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-md shadow-indigo-600/20 flex-shrink-0">
            <HelpCircle className="w-7 h-7" />
          </div>
          <div>
            <h4 className="text-base sm:text-lg font-bold text-slate-900">
              目標考核支援與諮詢管道
            </h4>
            <p className="text-slate-600 text-sm mt-1 leading-relaxed">
              若對目標設定或考核標準有任何疑問，請點擊下方按鈕，系統將自動為您安排與 HR 的諮詢會議。
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsOpen(true)}
          className="flex-shrink-0 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm shadow-md shadow-indigo-500/20 transition group"
        >
          <Calendar className="w-4 h-4 group-hover:scale-110 transition-transform" />
          <span>預約 HR 諮詢會議</span>
        </button>
      </div>

      {/* 預約成功確認訊息 */}
      {submittedBooking && (
        <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 flex items-start gap-3 animate-fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm">
            <div className="font-bold text-emerald-900">
              已成功為您提交 HR 諮詢會議預約需求！（單號：{submittedBooking.id}）
            </div>
            <div className="mt-1 text-emerald-700">
              諮詢主題：<strong>{submittedBooking.topic}</strong> | 預約時段：{submittedBooking.preferredTime}
            </div>
            <div className="text-[11px] text-emerald-600 mt-1">
              HR 團隊已收到通知，將於 24 小時內寄發 Google Calendar / Outlook 會議邀請至您的公務信箱。
            </div>
          </div>
        </div>
      )}

      {/* 彈出預約對話框 Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-100 overflow-hidden">
            {/* Modal Header */}
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Calendar className="w-5 h-5 text-indigo-400" />
                <h3 className="text-lg font-bold">預約 HR 考核與目標諮詢會議</h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-600" />
                  <span>預約人：<strong>{currentEmployee?.name}</strong> ({currentEmployee?.department} - {currentEmployee?.title})</span>
                </div>
                <div className="mt-1 text-[11px] text-slate-500 pl-6">
                  身分證字號：{currentEmployee?.nationalId} | 員工工號：{currentEmployee?.id}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  請選擇您想諮詢的主要議題：
                </label>
                <select
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full text-xs sm:text-sm p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                >
                  <option value="目標設定疑義與指標調整">目標設定疑義與指標調整</option>
                  <option value="考核計算標準與權重分配說明">考核計算標準與權重分配說明</option>
                  <option value="跨部門協作挑戰與資源支援爭取">跨部門協作挑戰與資源支援爭取</option>
                  <option value="年度調薪評等與個人職涯發展規劃">年度調薪評等與個人職涯發展規劃</option>
                  <option value="其他綜合個人反饋">其他綜合個人反饋</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  期望諮詢時段：
                </label>
                <select
                  value={preferredTime}
                  onChange={(e) => setPreferredTime(e.target.value)}
                  className="w-full text-xs sm:text-sm p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                >
                  <option value="下週二 14:00 - 15:00">下週二 14:00 - 15:00</option>
                  <option value="下週三 10:30 - 11:30">下週三 10:30 - 11:30</option>
                  <option value="下週四 15:00 - 16:00">下週四 15:00 - 16:00</option>
                  <option value="由 HR 依公務行事曆主動協調安排">由 HR 依公務行事曆主動協調安排</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  補充說明或具體疑問（選填）：
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="可在此簡述您遇到之目標制定疑問或希望 HR 協助對齊之面向..."
                  rows={3}
                  className="w-full text-xs sm:text-sm p-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition"
                >
                  確認自動預約會議
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
