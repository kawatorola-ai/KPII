import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { useKPI } from '../context/KPIContext';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle,
  AlertCircle,
  Download,
  RefreshCw,
  X,
  Layers,
  Sparkles
} from 'lucide-react';

export const HrExcelImporter = ({ isOpen, onClose }) => {
  const { importDataFromExcel, companyVision, employees, lastImportInfo } = useKPI();
  const [dragOver, setDragOver] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const fileInputRef = useRef(null);

  if (!isOpen) return null;

  // 下載標準 2026 KPI Excel 範本
  const handleDownloadTemplate = () => {
    try {
      const wb = XLSX.utils.book_new();

      // Sheet 1: 員工 KPI 資料
      const employeeRows = [
        {
          '身分證字號': 'A123456789',
          '姓名': '王大明',
          '部門': '業務部',
          '職稱': '資深業務經理',
          '指標類別': '業績營收',
          '指標名稱': '企業級客戶年度簽約營收',
          '目標值': 5000,
          '目前數值': 6200,
          '單位': '萬元',
          '權重%': 40,
          '達成率%': 124,
          '衡量說明': '達成 124% 超額突破'
        },
        {
          '身分證字號': 'A123456789',
          '姓名': '王大明',
          '部門': '業務部',
          '職稱': '資深業務經理',
          '指標類別': '新客開拓',
          '指標名稱': '高價值新簽約客戶數',
          '目標值': 20,
          '目前數值': 24,
          '單位': '家',
          '權重%': 30,
          '達成率%': 120,
          '衡量說明': '新增 24 家指標企業'
        },
        {
          '身分證字號': 'B234567890',
          '姓名': '林小涵',
          '部門': '研發部',
          '職稱': '資深前端工程師',
          '指標類別': '架構重構',
          '指標名稱': '微前端 Design System 覆蓋率',
          '目標值': 90,
          '目前數值': 85,
          '單位': '%',
          '權重%': 50,
          '達成率%': 94,
          '衡量說明': '全站元件現代化'
        },
        {
          '身分證字號': 'B234567890',
          '姓名': '林小涵',
          '部門': '研發部',
          '職稱': '資深前端工程師',
          '指標類別': '效能指標',
          '指標名稱': 'LCP 首屏效能加速',
          '目標值': 1.5,
          '目前數值': 1.4,
          '單位': '秒',
          '權重%': 50,
          '達成率%': 107,
          '衡量說明': '達成 P90 1.4 秒優秀標準'
        }
      ];

      const wsEmployees = XLSX.utils.json_to_sheet(employeeRows);
      XLSX.utils.book_append_sheet(wb, wsEmployees, '員工KPI指標');

      // Sheet 2: 公司願景目標
      const visionRows = [
        {
          '年度': 2026,
          '公司營收目標(元)': 250000000,
          '目前累積營收(元)': 195000000,
          '目標備註': '2.5 億元年度營收共同目標'
        }
      ];
      const wsVision = XLSX.utils.json_to_sheet(visionRows);
      XLSX.utils.book_append_sheet(wb, wsVision, '公司營收目標');

      XLSX.writeFile(wb, '2026_KPI_員工指標匯入範本.xlsx');
    } catch (err) {
      console.error('產生範本失敗', err);
      setErrorMsg('產生範本失敗：' + err.message);
    }
  };

  // 處理檔案解析
  const processFile = (file) => {
    if (!file) return;
    setErrorMsg('');
    setSuccessMsg('');
    setParsing(true);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buffer = e.target.result;
        const workbook = XLSX.read(buffer, { type: 'array' });

        let parsedCompanyVision = null;
        let parsedEmployeesMap = {};

        // 1. 檢查是否有「公司營收目標」工作表
        const visionSheetName = workbook.SheetNames.find(
          name => name.includes('公司') || name.includes('營收') || name.includes('願景') || name.includes('Vision')
        );

        if (visionSheetName) {
          const visionData = XLSX.utils.sheet_to_json(workbook.Sheets[visionSheetName]);
          if (visionData.length > 0) {
            const row = visionData[0];
            const goalRev = Number(row['公司營收目標(元)'] || row['營收目標'] || row['目標營收'] || 250000000);
            const currRev = Number(row['目前累積營收(元)'] || row['目前營收'] || row['累積營收'] || 0);
            parsedCompanyVision = {
              goalRevenue: goalRev,
              currentRevenue: currRev,
              subTitle: `已由 HR 匯入更新（目標：${(goalRev / 100000000).toFixed(1)} 億元）`
            };
          }
        }

        // 2. 解析員工 KPI 工作表 (預設取第一個或名為「員工」的工作表)
        const empSheetName = workbook.SheetNames.find(
          name => name.includes('員工') || name.includes('KPI') || name.includes('指標')
        ) || workbook.SheetNames[0];

        const empRows = XLSX.utils.sheet_to_json(workbook.Sheets[empSheetName]);

        if (!empRows || empRows.length === 0) {
          throw new Error('未讀取到有效的員工 KPI 數據，請確認 Excel 工作表內容！');
        }

        empRows.forEach((row, idx) => {
          const nationalId = String(row['身分證字號'] || row['身分證'] || row['ID'] || `EMP_${idx}`).trim().toUpperCase();
          const name = String(row['姓名'] || row['員工姓名'] || '未知員工').trim();
          const department = String(row['部門'] || '營運部').trim();
          const title = String(row['職稱'] || '專業同仁').trim();

          if (!parsedEmployeesMap[nationalId]) {
            parsedEmployeesMap[nationalId] = {
              id: `EMP-${nationalId.slice(-4)}`,
              nationalId,
              name,
              department,
              title,
              metrics: []
            };
          }

          // 讀取該筆指標
          const target = Number(row['目標值'] || 100);
          const current = Number(row['目前數值'] || row['達成數值'] || 0);
          const rawAchievement = row['達成率%'] !== undefined ? Number(row['達成率%']) : (target > 0 ? Math.round((current / target) * 100) : 0);
          const weight = Number(row['權重%'] || row['權重'] || 25);

          parsedEmployeesMap[nationalId].metrics.push({
            id: `M-${idx + 1}`,
            category: String(row['指標類別'] || '核心工作'),
            title: String(row['指標名稱'] || row['KPI名稱'] || `指標項目 ${idx + 1}`),
            targetNum: target,
            currentNum: current,
            unit: String(row['單位'] || '項'),
            weight: weight,
            achievement: rawAchievement,
            description: String(row['衡量說明'] || row['關鍵結果衡量'] || '年度關鍵成果指標')
          });
        });

        // 轉換為陣列並計算每位員工的綜合達成率
        const employeeList = Object.values(parsedEmployeesMap).map(emp => {
          let totalWeight = 0;
          let weightedSum = 0;
          emp.metrics.forEach(m => {
            const w = m.weight || 25;
            totalWeight += w;
            weightedSum += (m.achievement || 0) * w;
          });

          const overall = totalWeight > 0 ? Math.round(weightedSum / totalWeight) : 0;
          let statusBadge = '穩定推進';
          let statusColor = 'indigo';
          if (overall >= 100) {
            statusBadge = '超額卓越';
            statusColor = 'emerald';
          } else if (overall < 80) {
            statusBadge = '需加速衝刺';
            statusColor = 'amber';
          }

          return {
            ...emp,
            overallAchievement: overall,
            statusBadge,
            statusColor
          };
        });

        setPreviewData({
          fileName: file.name,
          employeeCount: employeeList.length,
          totalMetricCount: empRows.length,
          updatedCompanyVision: parsedCompanyVision,
          updatedEmployees: employeeList
        });
        setParsing(false);
      } catch (err) {
        console.error('Excel 解析失敗', err);
        setErrorMsg('Excel 檔案解析失敗：' + err.message);
        setParsing(false);
      }
    };

    reader.onerror = () => {
      setErrorMsg('無法讀取該檔案，請檢查檔案格式！');
      setParsing(false);
    };

    reader.readAsArrayBuffer(file);
  };

  // 確認套用更新
  const handleApplyImport = () => {
    if (!previewData) return;

    importDataFromExcel({
      updatedCompanyVision: previewData.updatedCompanyVision,
      updatedEmployees: previewData.updatedEmployees,
      fileName: previewData.fileName
    });

    setSuccessMsg(`成功匯入 ${previewData.employeeCount} 位員工、共 ${previewData.totalMetricCount} 筆指標！系統已同步動態更新。`);
    setPreviewData(null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl backdrop-blur-sm">
              <FileSpreadsheet className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h3 className="text-lg font-bold">HR 專用 Excel (.xlsx) 數據匯入管理</h3>
              <p className="text-xs text-emerald-200/90">
                動態解析並覆蓋 2.5 億元公司營收與員工 OKR/KPI 目標狀態
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-600 font-medium">
              支援 Excel (.xlsx, .xls) 格式。上傳後系統圖表將即時自動重新渲染。
            </span>
            <button
              onClick={handleDownloadTemplate}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-emerald-50 border border-slate-300 hover:border-emerald-300 text-emerald-700 font-semibold rounded-lg shadow-sm transition flex-shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>下載 2026 KPI 範本 Excel</span>
            </button>
          </div>

          {/* Drag & Drop Upload Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
              dragOver
                ? 'border-emerald-500 bg-emerald-50/70 scale-[1.01]'
                : 'border-slate-300 hover:border-emerald-400 bg-slate-50/50 hover:bg-slate-50'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".xlsx, .xls, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
              className="hidden"
            />
            <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-100/70 text-emerald-600 flex items-center justify-center mb-3">
              <UploadCloud className="w-7 h-7" />
            </div>
            <h4 className="text-sm font-bold text-slate-800 mb-1">
              點擊選擇檔案，或直接拖曳 Excel (.xlsx) 至此處
            </h4>
            <p className="text-xs text-slate-500">
              支援包含「員工KPI指標」與「公司營收目標」之工作表
            </p>
          </div>

          {/* Loading Indicator */}
          {parsing && (
            <div className="flex items-center justify-center gap-2 p-4 text-xs font-semibold text-emerald-700 bg-emerald-50 rounded-xl">
              <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
              <span>SheetJS 正在讀取並解析 Excel 數據，請稍候...</span>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="flex items-start gap-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold">解析異常：</strong> {errorMsg}
              </div>
            </div>
          )}

          {/* Success Message */}
          {successMsg && (
            <div className="flex items-start gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs">
              <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-emerald-600" />
              <div>{successMsg}</div>
            </div>
          )}

          {/* Preview Parsed Data */}
          {previewData && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>檔案預覽：{previewData.fileName}</span>
                </div>
                <span className="text-[11px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
                  解析成功
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">員工數目 / 總指標數</span>
                  <span className="font-bold text-slate-800 text-sm">
                    {previewData.employeeCount} 位員工 / {previewData.totalMetricCount} 條指標
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">公司營收目標更新</span>
                  <span className="font-bold text-emerald-700 text-sm">
                    {previewData.updatedCompanyVision
                      ? `NT$ ${(previewData.updatedCompanyVision.goalRevenue / 100000000).toFixed(1)} 億 (目前 ${((previewData.updatedCompanyVision.currentRevenue / previewData.updatedCompanyVision.goalRevenue) * 100).toFixed(1)}%)`
                      : '維持目前設定'}
                  </span>
                </div>
              </div>

              {/* Parsed Employees Table Preview */}
              <div className="max-h-36 overflow-y-auto text-xs border border-slate-200 rounded-lg bg-white">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 text-slate-600 text-[11px] sticky top-0">
                    <tr>
                      <th className="p-2">身分證</th>
                      <th className="p-2">姓名</th>
                      <th className="p-2">部門</th>
                      <th className="p-2">指標數</th>
                      <th className="p-2">綜合達成率</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {previewData.updatedEmployees.map((emp, i) => (
                      <tr key={i} className="hover:bg-slate-50">
                        <td className="p-2 font-mono">{emp.nationalId}</td>
                        <td className="p-2 font-semibold text-slate-800">{emp.name}</td>
                        <td className="p-2 text-slate-600">{emp.department}</td>
                        <td className="p-2">{emp.metrics.length} 項</td>
                        <td className="p-2">
                          <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                            emp.overallAchievement >= 100 ? 'bg-emerald-100 text-emerald-700' :
                            emp.overallAchievement >= 80 ? 'bg-indigo-100 text-indigo-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {emp.overallAchievement}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPreviewData(null)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  取消重選
                </button>
                <button
                  type="button"
                  onClick={handleApplyImport}
                  className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition flex items-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>立即套用並覆蓋系統數據</span>
                </button>
              </div>
            </div>
          )}

          {/* Last Import Info */}
          {lastImportInfo && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500 flex items-center justify-between">
              <span>上次更新：{lastImportInfo.fileName} ({lastImportInfo.time})</span>
              <span className="text-emerald-700 font-medium">已同步至儀表板</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Excel 解析由 SheetJS (xlsx) 核心驅動</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 rounded-xl font-medium text-slate-700 transition"
          >
            關閉視窗
          </button>
        </div>
      </div>
    </div>
  );
};
